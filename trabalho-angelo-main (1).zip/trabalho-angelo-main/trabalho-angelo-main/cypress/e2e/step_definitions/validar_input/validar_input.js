import { Given, When, Then } from 'cypress-cucumber-preprocessor/steps';

Given('Estou na página de simulação de frete dos Correios', () => {
    cy.visit('https://www.correios.com.br/'); // URL da página de simulação
});

When('Preencho os campos de CEP de origem, CEP de destino e as dimensões da encomenda', () => {
    // Preenchendo os campos
    cy.get('#origem').type('01001000'); // CEP de origem
    cy.get('#destino').type('02012000'); // CEP de destino
    cy.get('#altura').type('50'); // Altura
    cy.get('#largura').type('50'); // Largura
    cy.get('#comprimento').type('50'); // Comprimento
});

When('Clico no botão de Calcular Frete', () => {
    cy.contains('Calcular Frete').click();
});

Then('A simulação de frete deve ser processada com sucesso', () => {
    // Validar se a simulação foi realizada
    cy.get('.resposta-precos-e-prazos').should('be.visible');
});
