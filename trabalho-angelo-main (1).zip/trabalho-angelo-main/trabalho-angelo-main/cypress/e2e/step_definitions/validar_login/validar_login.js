import { Given, When, Then } from 'cypress-cucumber-preprocessor/steps';

Given('Estou na página de login dos Correios', () => {
  cy.visit('https://cas.correios.com.br/login?service=https%3A%2F%2Fmeucorreios.correios.com.br%2Fcore%2Fseguranca%2Fservice.php');
});

When('Preencho os campos de login com credenciais válidas', () => {
  cy.get('#username').type('usuario_teste');
  cy.get('#password').type('senha_teste');
});

When('Clico no botão de ENTRAR', () => {
  cy.get('button[name="submitBtn"]').click();
});

Then('Devo ser redirecionado para o portal Meu Correios', () => {
  cy.url().should('include', '/meucorreios');
});
